package com.jpa.example.lcwd_jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LcwdJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(LcwdJpaApplication.class, args);
	}

}
